#include <sys/types.h>
#include <netinet/in.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

#include <afs/param.h>
#include <afs/cellconfig.h>

#define NTOHL(x)  (x) = ntohl(x)
#define NTOHS(x)  (x) = ntohs(x)

#include "crack.h"

/* Transarc licensing neccesitates this obscurity. If you have a source
 * license, consult src/kauth/kaserver.h for the real struct definitions.
 */

#define KADBVERSION     5               /* the database version */

#define HASHSIZE        8191            /* pick a prime for the length */

/* all fields are stored in network (sun or rt) byte order */
struct kaheader {
    long           version;             /* database version number */
    long           headerSize;          /* bytes in header, for skipping in bad times */
    long           freePtr;             /* first (if any) free entry in freelist */
    long           eofPtr;              /* first free byte in file */
    long           kvnoPtr;             /* first special name old keys entry */
    struct kasstats stats;              /* track interesting statistics */
    long           admin_accounts;      /* total number of users w/ admin flag set */
    long           specialKeysVersion;  /* inc if special name gets new key */
    long           hashsize;            /* allocated size of nameHash */
#if (KADBVERSION > 5)
    long           spare[10];           /* allocate some spares next time */
#endif
    long           nameHash[HASHSIZE];  /* hash table for names */
    long           checkVersion;        /* database version number, same as first field */
};

#define ENTRYSIZE               200
#define PADLEN                  (ENTRYSIZE - sizeof(kaident) - sizeof(struct ktc_encryptionKey) - 10*4)

/* all fields are stored in network byte order */
struct kaentry {
    long           flags;               /* random flags */
    long           next;                /* next block same entry (or freelist) */
    Date           user_expiration;     /* user registration good till then */
    Date           modification_time;   /* time of last update */
    long           modification_id;     /* identity of user doing update */
    Date           change_password_time;/* time user last changed own password */
    long           max_ticket_lifetime; /* maximum lifetime for tickets */
    long           key_version;         /* verson number of this key */
    union { /* overload several miscellaneous fields */
        struct {
            long   nOldKeys;            /* number of outstanding old keys */
            long   oldKeys;             /* block containing old keys */
        } asServer; /* for principals that are part of the AuthServer itself */
        struct {
            long   maxAssociates;       /* associates this user can create */
            long   nInstances;          /* number of instances user's created */
        } assocRoot; /* for principals at root of associate tree */
        struct {
            long   root;                /* identity of this instance's root */
            long   spare;
        } associate; /* associate instance */
    } misc;
    /* put the strings last to simplify alignment calculations */
    struct kaident userID;              /* user and instance names */
    struct ktc_encryptionKey key;       /* the key to use */
    char           padding[PADLEN];     /* pad to 200 bytes */
};
typedef struct kaentry kaentry;

static int nusers = 0;
static int ncrack = 0;

int keycompare(u1, u2)
struct USER *u1, *u2;
{
    return memcmp((char *) &u1->key, (char *) &u2->key,
	sizeof(struct ktc_encryptionKey));
}

LoadData()
{
    struct ubik_hdr uheader;
    struct kaheader dbheader;
    struct kaentry dbentry;
    struct USER *ldptr;
    int n, nloaded = 0;
    char filename[1024];
    FILE *fp;

    /* This is strange. If you call ka_StringToKey with a non-NULL
     * cellname, it will invoke the entire Afsconf package to map
     * the cellname to a realm. This involves stat(3), and is
     * slow. So don't. If your machine's default cell and the cell
     * that the database comes from don't agree, modify the strcpy
     * appropriately. This is very rare so I don't deal with it.
     */
#ifdef notdef
    sprintf(filename, "%s/ThisCell", AFSCONF_SERVERNAME);
    fp = fopen(filename, "r");
    if (!fp) {
	sprintf(filename, "%s/ThisCell", AFSCONF_CLIENTNAME);
	fp = fopen(filename, "r");
    }
    if (fp) {
        fgets(cell, 1024, fp);
        (void)fclose(fp);
    } else {
	Log("Can't find ThisCell - this doesn't look like an AFS server!\n");
	exit(1);
    }
#else
    strcpy(cell, "");
#endif

    n = read(fileno(stdin), (char *) &uheader, sizeof(struct ubik_hdr));
    if (n != sizeof(struct ubik_hdr)) {
	Log("Read of Ubik database header failed - only got %ld bytes of %ld\n",
	    n,
	    sizeof(struct ubik_hdr));
	return -1;
    }

    NTOHL(uheader.magic);
    NTOHS(uheader.size);
    NTOHL(uheader.version.epoch);
    NTOHL(uheader.version.counter);

    n = lseek(fileno(stdin), 64, SEEK_SET);
    if (n == -1) {
	perror("lseek");
	Log("Cannot lseek in AFS kerberos database - fatal errorn\n");
	return -1;
    }

    n = read(fileno(stdin), (char *) &dbheader, sizeof(struct kaheader));
    if (n != sizeof(struct kaheader)) {
	Log("Read of KA database header failed - only got %ld bytes of %ld\n",
	    n,
	    sizeof(struct kaheader));
	return -1;
    }

    NTOHL(dbheader.headerSize);
    NTOHL(dbheader.stats.minor_version);
    NTOHL(dbheader.stats.allocs);
    NTOHL(dbheader.stats.frees);
    NTOHL(dbheader.stats.cpws);

    Log("Ubik: magic = %ld, header %d (%ld) bytes, %ld transactions, start %s",
	   uheader.magic,
	   uheader.size,
	   sizeof(struct ubik_hdr),
	   uheader.version.counter,
	   ctime(&uheader.version.epoch));
    Log("Database: header %ld (%ld) bytes\n",
	   dbheader.headerSize,
	   sizeof(struct kaheader));
    Log("KAStats: minor version %ld, allocs %ld, frees %ld, cpws %ld\n",
	   dbheader.stats.minor_version,
	   dbheader.stats.allocs,
	   dbheader.stats.frees,
	   dbheader.stats.cpws);

    /* count # of data-full blocks in DB. blech */
    for (;;) {
       n = read(fileno(stdin), (char *) &dbentry, sizeof(struct kaentry));
       if (! n) break;

       if (n != sizeof(struct kaentry)) {
	   Log("Got short read %ld bytes at end of database (probably harmless)\n", n);
	   break;
       }

       if (! *dbentry.userID.name) continue;

       nusers++;
    }

    Log("Found %ld keys in database\n", nusers);
    
    /* seek back to start of data */
    n = lseek(fileno(stdin), 64 + sizeof(struct kaheader), SEEK_SET);
    if (n == -1) {
	perror("lseek");
	return -1;
    }

    ldptr = userroot = (struct USER *) malloc(nusers * sizeof(struct USER));
    if (!userroot) {
	Log("LoadData/malloc() failed! Fatal lack of memory!\n");
	exit(1);
    }

    /* now we actually load everything in place */
    for (;;) {
       n = read(fileno(stdin), (char *) &dbentry, sizeof(struct kaentry));
       if (n != sizeof(struct kaentry)) break;
       if (! *dbentry.userID.name) continue;

       if (nloaded + 1 > nusers) {
	   Log("Database changed size during load!");
	   exit(1);
       }

       bcopy(&dbentry.key, &ldptr->key, sizeof(struct ktc_encryptionKey));
       bcopy(&dbentry.userID, &ldptr->kaid, sizeof(struct kaident));
       ldptr->done = 0;
       if (!dbentry.change_password_time)
	 if (*ldptr->kaid.instance)
	   Log("%s.%s has original password\n", ldptr->kaid.name, ldptr->kaid.instance);
	 else
	   Log("%s has original password\n", ldptr->kaid.name);
       ldptr++;
       nloaded++;
    }

    Log("Loaded %ld keys from database\n", nloaded);
    
    /* we will be using bsearch(3) on this data ... */
    qsort((char *) userroot, nusers, sizeof(struct USER), keycompare);

    return nusers;
}

TryManyUsers(guess)
char *guess;
{
    struct ktc_encryptionKey keyguess;
    struct USER *uptr = NULL;

    ka_StringToKey(guess, cell, &keyguess);

    uptr = (struct USER *) bsearch((char *) &keyguess, userroot,
		   nusers, sizeof(struct USER), keycompare);

    if (uptr) {
	/* since keys within a cell are only a function of the password,
	 * we have to search around our entry to get duplicate instances
	 * of this key we have found
	 */

	for (; uptr > userroot; uptr--) {
	    if (keycompare((struct USER *) uptr, 
			   (struct USER *) (uptr - 1)))
	      break;
	}
	for (; uptr < (userroot + nusers); uptr++) {
	    PrintGuess(uptr, guess);
	    if (!uptr->done) {
		ncrack++;
		uptr->done = 1;
	    }
	    if (keycompare((struct USER *) uptr, 
			   (struct USER *) (uptr + 1)))
	      break;
	}
	/* at this point we could smash the array together with bcopy() */
    }

    return 1;
}	      

Pass1()
{
    Log("No gecos-like information in kerberos databases - skipping Pass1\n");
}

void
Pass2 (dictfile)
    char *dictfile;
{
    int pointuser;
    struct USER *userptr;
    struct RULE *ruleptr;
    struct DICT *dictptr;

    Log ("Starting pass 2 - dictionary words\n");
    ruleptr = (struct RULE *) 0;

    /* check if we are recovering from a crash */
    if (recover_bool)
    {
	recover_bool = 0;	/* switch off */

	for (ruleptr = ruleroot;
	     ruleptr && strcmp (ruleptr -> rule, old_rule);
	     ruleptr = ruleptr -> next);

	if (!ruleptr)
	{
	    Log ("Fatal: Ran off end of list looking for rule '%s'\n",
		 old_rule);
	    exit (1);
	}
    }
    /* start iterating here */
    for (ruleptr = (ruleptr ? ruleptr : ruleroot);
	 ruleptr;
	 ruleptr = ruleptr -> next)
    {
	long int rval;
	int continue_dict;

	continue_dict = 0;

      load_dict:
	rval = LoadDict (dictfile, ruleptr -> rule, continue_dict);

	if (rval == 0)
	{
	    Log ("Oops! I got an empty dictionary! Skipping rule '%s'!\n",
		 ruleptr -> rule);
	    continue;
	}
	pointuser = 0;

	SetPoint (dictfile,
		  ruleptr -> rule, 0, NULL);

	/* iterate all the words */
	for (dictptr = dictroot;
	     dictptr;
	     dictptr = dictptr -> next)
	  {
	      /* skip repeated words... */
	      if (!TryManyUsers (dictptr -> word))
		{
		    break;
		}
	  }
    
	/* free up memory */
	DropDict ();

	/* write feedback file */
	if (!FeedBack (0))
	{
	    Log ("FeedBack: All Users Are Cracked! Bloody Hell!\n");
	    return;
	}

	/* did we REALLY finish this dictionary ? */
	if (rval < 0)
	{
	    continue_dict = 1;
	    goto load_dict;
	}
    }
}

FeedBack()
{
    Log("Feedback: %ld users done, %ld remaining\n", ncrack, nusers - ncrack);

    return (nusers - ncrack);
}
