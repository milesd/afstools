#include <ctype.h>

char *ctob(i)
unsigned char i;
{
	static char buf[9];
	unsigned char c = 0x80;
	int d = 0;

	for (; c; c >>= 1, d++)
		buf[d] = (i&c ? '1' : '0');
	buf[d+1] = '\0';

	return buf;
}

main () {
	unsigned char i;

	for (i = 0; i < 128; i++) {
		printf("%s %3d %3x %3o", ctob(i), i, i, i);
		if (isprint(i))
			if (i >= 0x60 && i <= 0x67)
				printf("\t%c\t%c\n", i, i-0x28);
			else if (i >= 0x68 && i <= 0x6f)
				printf("\t%c\t%c\n", i, i-0x38);
			else if (i >= 0x70 && i <= 0x77)
				printf("\t%c\t%c\n", i, i-0x48);
			else if (i >= 0x78 && i <= 0x7f)
				printf("\t%c\t%c\n", i, i-0x58);
			else printf("\t%c\n", i);
		else
			putchar('\n');
	}
}
