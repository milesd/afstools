#!/usr/bin/perl

$found_pass2 = 0;
$in_rule = 0;
$words_in_dict = 0;
$words_this_rule = 0;
$words_this_dict = 0;
$guessed_this_rule = 0;
$guessed_this_dict = 0;

format STDOUT =
# rule            dict-words percent-of-dict guessed new total
@>>>>>>>>>>>>>>>>>>>>>>  @######     @##.#%        @#####   @##### @#####
"$cur_rule", $words_this_rule, $percent_of_dict, $guessed_this_rule, $new_this_rule, $guessed_this_dict
.

print "Rule                      Words Used  %Dict Used     Guessed  New    Total\n";
print "--------------------------------------------------------------------------\n";
while (<>) {
	if (! $found_pass2) {
		if (/Starting pass 2/o) {
			$found_pass2 = 1;
			next;
		}
	}

	if (/Applying rule/o) {
		split;
		$cur_rule = $_[6];
		$this_dict = $_[$#_];
		if ($this_dict ne $cur_dict) {
			if ($cur_dict ne "") {
				print "+++++ DICTIONARY $cur_dict got $new_this_dict\n";
			}
			print "***** NEW DICTIONARY $this_dict\n";
			$cur_dict = $this_dict;
			$new_this_dict = 0;
		}
		$in_rule = 1;
		next;
	}

	if (/Done\.$/) {
		print "+++++ DICTIONARY $cur_dict got $new_this_dict\n";
		$new_this_dict = 0;
	}

	next if ! $in_rule;

	if (/Oops! I got an empty/o) {
		$in_rule = 0;
		next;
	}

	if (/words on loading/o) {
		split;
		$words_in_dict = $_[5] + $_[9];
		next;
	}

	if (/FINAL DICTIONARY SIZE/o) {
		split;
		$words_this_rule = $_[11];
		$words_this_dict += $_[11];
		next;
	}

	$guessed_this_rule++ if (/[Gg]uessed/);

	if (/Feedback:/o) {
		next if ! $guessed_this_rule;
		split;
		$remaining = $_[8];
		$new_this_rule = $_[5] - $guessed_this_dict;
		$new_this_dict += $new_this_rule;
		$guessed_this_dict = $_[5];
		$percent_of_dict = $words_this_rule/$words_in_dict * 100;

		write;

		$guessed_this_rule = 0;
		$in_rule = 0;
	}
}

print "--------------------------------------------------------------------------\n";
print "Generated $words_this_dict words from this set of dict\n";
