#!/usr/bin/perl

# This script should be fed a passwd file on stdin.
# It will produce a list of words on stdout, splitting
# names up into individual words. The output should normally
# be run through sort | uniq for Crack's purposes.

while (<>) {
	@arry = split(/:/);

	print "$arry[0]\n";

	print "$arry[2]\n";

	@gecos = split(/ /, $arry[4]);

	for (@gecos) {
		s/\.//;
		s/,//;
	}

	print "$gecos[0]\n";
	print "$gecos[$#gecos]\n";
	if ($#gecos > 1) {
		for (1 .. $#gecos-1) {
			print "$gecos[$_]\n";
		}
	}
}
