#!/usr/bin/perl

#
# This script generates a very simple 4-digit number
# dictionary. Numbers like these are often used as
# Personal Identification Numbers (PINs) for banking
# services, etc.
#

foreach $i (0..9) {
	foreach $j (0..9) {
		foreach $k (0..9) {
			foreach $l (0..9) {
				print "$i$j$k$l\n";
			}
		}
	}
}
