#!/usr/bin/perl

#
# This script should remove the printed passwords from
# your Crack output if you compiled crack-pwc with
# -DPRINTPASSWORD. Supply the output file on stdin. Use this
# if you want to hand off the output to someone who doesn't
# need to see them.
#

while (<>) {
	if (/(.*)\s\[.*\]/) {
		print "$1\n";
		next;
	}
	print;
}
