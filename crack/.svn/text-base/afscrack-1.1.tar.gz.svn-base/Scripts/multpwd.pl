#!/usr/bin/perl

#
# This script will discover people who were cracked with
# multiple passwords from your Crack output if you compiled
# crack-pwc with -DPRINTPASSWORD. Supply the output file on
# stdin. This was the script used to start figuring out the
# report in transpose/
#

while (<>) {
	if (/ssed\s+(.*)\s+\[(.*)\]$/) {
		if (! defined $password{$1}) {
			$password{$1} = $2;
		}
		elsif ($password{$1} ne $2) {
			print "$1 via $password{$1} and $2\n";
		}
	}
}
