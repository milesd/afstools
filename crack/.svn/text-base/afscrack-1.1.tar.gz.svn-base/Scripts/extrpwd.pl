#!/usr/bin/perl

#
# This script will generate a dictionary of guessed passwords
# from your Crack output if you compiled crack-pwc with
# -DPRINTPASSWORD. Supply the output file on stdin.
#

while (<>) {
	if (/Guessed\s+(.*)\s+\[(.*)\]$/) {
		print "$2\n";
	}
}

