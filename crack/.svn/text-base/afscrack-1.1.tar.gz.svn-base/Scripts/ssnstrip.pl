#!/usr/bin/perl

# This is somewhat CMU-specific, but if you have a list
# of Social Security Numbers, this will render them from
# 9 to 8 characters.

while (<>) {
	chop;
	($d) = /(........)/;
	print "$d\n";
}
