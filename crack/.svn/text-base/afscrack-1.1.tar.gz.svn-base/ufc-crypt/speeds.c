/*
 * This fcrypt/crypt speed testing program
 * is derived from one floating around in
 * the net. It's distributed along with
 * UFC-crypt but is not.
 *
 * @(#)speeds.c	1.6 02/08/92
 */

#include <sys/time.h>
#include <signal.h>
#include <stdio.h>
#ifdef AFSKERB
#include <afs/param.h>
#include <afs/auth.h>
#endif

static int cnt;
#define ITIME	10		/* Number of seconds to run test. */

void
Stop ()
{
    printf ("Did %f %s()s per second.\n",
	    ((float) cnt) / ((float) ITIME),
#if defined(FCRYPT)
	    "fcrypt"
#else
#ifdef AFSKERB
	    "ka_StringToKey"
#else
	    "crypt"
#endif
#endif
    );
    exit (0);
}

/*
 * Silly rewrite of 'bzero'. I do so
 * because some machines don't have
 * bzero and some don't have memset.
 */

static void clearmem(start, cnt)
  char *start;
  int cnt;
  { while(cnt--)
      *start++ = '\0';
  }

main ()
{
    struct itimerval itv;
#ifdef AFSKERB
    struct ktc_encryptionKey keyval;
#endif
    clearmem (&itv, sizeof (itv));

    printf ("Running %s for %d seconds of virtual time ...\n",
#ifdef FCRYPT
    "UFC-crypt",
#else
#ifdef AFSKERB
    "ka_StringToKey",
#else
    "crypt(libc)",
#endif
#endif
	    ITIME);

#if defined(FCRYPT) || defined(AFSKERB)
    init_des ();
#endif

    signal (SIGVTALRM, Stop);
    itv.it_value.tv_sec = ITIME;
    itv.it_value.tv_usec = 0;
    setitimer (ITIMER_VIRTUAL, &itv, NULL);

    for (cnt = 0;; cnt++)
    {
#ifdef FCRYPT
	crypt ("fredfred", "eek");
#else
#ifdef AFSKERB
        ka_StringToKey("fredfredbb", "andrew.cmu.edu", &keyval);
#else
	crypt ("fredfred", "eek");
#endif
#endif
    }
}
